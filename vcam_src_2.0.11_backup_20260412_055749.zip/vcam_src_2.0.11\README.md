﻿# VCAM Clone (iOS jailbreak plugin)

This project recreates a compatible iOS side plugin for the desktop app we just built.

## What it does

- Connects to desktop stream via `TCP host:port` (default `7878`)
- Reads packets as: `4-byte big-endian length + raw H264 NALU`
- Decodes H264 with `VideoToolbox`
- Replaces camera sample buffers in apps by hooking AVFoundation delegates
- Provides `vcamctl` command to configure host/port and enable/disable

## Files

- `Tweak.xm`: main virtual-camera hook + stream receiver
- `vcamctl.m`: command line config tool
- `VCAMClone.plist`: substrate filter
- `control`: package metadata
- `Makefile`: Theos build config

## Build (Theos)

1. Copy this folder to a Theos environment (macOS/Linux/iOS with Theos).
2. Build package:

```bash
make package
```

3. Install generated `.deb` on jailbroken iPhone/iPad.

## Configure on phone

```bash
vcamctl status
vcamctl enable 192.168.6.160 7878
# or
vcamctl set 192.168.6.160 7878

# disable
vcamctl disable
```

Config file path:

- `/var/tmp/vcam_stream.conf`

Darwin notifications used:

- `com.vcam.stream.config`
- `com.vcam.media.stream.recv`

## Desktop side requirements

- Start desktop app stream in LAN
- Phone and PC must be on same LAN
- Use the same IP/port in `vcamctl`

## Notes

- This is a clean-room clone for compatibility with your new desktop tool.
- Because it hooks app-level camera callbacks, behavior can vary by app implementation.
- If a target app uses a non-standard capture path, additional app-specific hooks may be needed.
