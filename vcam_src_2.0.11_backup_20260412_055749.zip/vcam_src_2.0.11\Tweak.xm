#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreMedia/CoreMedia.h>
#import <CoreVideo/CoreVideo.h>
#import <CoreImage/CoreImage.h>
#import <QuartzCore/QuartzCore.h>
#import <ImageIO/ImageIO.h>
#import <objc/message.h>
#import <notify.h>
#import <os/lock.h>
#import <substrate.h>
#import <math.h>
#import <arpa/inet.h>
#import <sys/socket.h>
#import <sys/types.h>
#import <errno.h>
#import <fcntl.h>
#import <unistd.h>

static NSString *const kVCAMConfigPath     = @"/var/tmp/vcam_stream.conf";
static NSString *const kVCAMProcessLogPath = @"/var/tmp/vcam_proc.log";
static NSString *const kVCAMMediaLogPath   = @"/var/tmp/vcam_media.log";
static const char *kVCAMConfigNotify       = "com.vcam.stream.config";
static const char *kVCAMMediaNotify        = "com.vcam.media.stream.recv";

static CVImageBufferRef (*gOrigCMSampleBufferGetImageBuffer)(CMSampleBufferRef sampleBuffer) = NULL;
static CFTimeInterval  gVCAMLastManagerSyncAt  = 0;
static uint64_t        gVCAMHookProbeCount     = 0;

// PTS 时间戳锁：确保同一帧最多覆写一次，防止录像模式 GPU 死锁
static CMTime         gLastReplacedPTS = {0, 0, 0, 0};
static os_unfair_lock g_ptsLock        = OS_UNFAIR_LOCK_INIT;

// ── 帧渲染缓存（缓存 + CPU Memcpy 架构）─────────────────────────────────────────
//  同一张网络帧图片只做一次 GPU/CPU 渲染，后续所有调用直接 memcpy，
//  彻底杜绝录像模式 VideoToolbox 高频调用引发的 GPU 死锁。
static CGImageRef       gLastRenderedFakeImage = NULL;  // 裸指针比较键，不持有引用
static CVPixelBufferRef gCachedScaledBuffer    = NULL;  // 持有引用
static os_unfair_lock   g_cacheLock            = OS_UNFAIR_LOCK_INIT;

// ─── TCP helpers ──────────────────────────────────────────────────────────────
static BOOL VCAMReadExact(int fd, void *buffer, size_t length) {
    uint8_t *ptr = (uint8_t *)buffer;
    size_t done = 0;
    while (done < length) {
        ssize_t r = recv(fd, ptr + done, length - done, 0);
        if (r <= 0) return NO;
        done += (size_t)r;
    }
    return YES;
}

static int VCAMConnectWithTimeout(const char *host, int port, int timeoutSec) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return -1;

    int flags = fcntl(fd, F_GETFL, 0);
    if (flags >= 0) fcntl(fd, F_SETFL, flags | O_NONBLOCK);

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_len    = sizeof(addr);
    addr.sin_family = AF_INET;
    addr.sin_port   = htons((uint16_t)port);
    if (inet_pton(AF_INET, host, &addr.sin_addr) != 1) {
        close(fd); errno = EINVAL; return -1;
    }

    int r = connect(fd, (struct sockaddr *)&addr, sizeof(addr));
    if (r != 0 && errno != EINPROGRESS) {
        int e = errno; close(fd); errno = e; return -1;
    }

    if (r != 0) {
        fd_set wfds; FD_ZERO(&wfds); FD_SET(fd, &wfds);
        struct timeval tv = { timeoutSec > 0 ? timeoutSec : 2, 0 };
        int sel = select(fd + 1, NULL, &wfds, NULL, &tv);
        if (sel <= 0) {
            int e = (sel == 0) ? ETIMEDOUT : errno; close(fd); errno = e; return -1;
        }
        int soError = 0; socklen_t soLen = sizeof(soError);
        if (getsockopt(fd, SOL_SOCKET, SO_ERROR, &soError, &soLen) != 0 || soError != 0) {
            int e = soError ? soError : errno; close(fd); errno = e; return -1;
        }
    }

    if (flags >= 0) fcntl(fd, F_SETFL, flags);
    return fd;
}

// ─── CMSampleBuffer attachment helper ────────────────────────────────────────
static void VCAMSetSampleAttachments(CMSampleBufferRef sample) {
    if (!sample) return;
    CFArrayRef attachments = CMSampleBufferGetSampleAttachmentsArray(sample, YES);
    if (!attachments || CFArrayGetCount(attachments) <= 0) return;
    CFMutableDictionaryRef dict = (CFMutableDictionaryRef)CFArrayGetValueAtIndex(attachments, 0);
    if (!dict) return;
    CFDictionarySetValue(dict, kCMSampleAttachmentKey_DisplayImmediately, kCFBooleanTrue);
    CFDictionaryRemoveValue(dict, kCMSampleAttachmentKey_NotSync);
}

@class VCAMService;

// ─── Logging ──────────────────────────────────────────────────────────────────
static void VCAMAppendLog(NSString *path, NSString *line) {
    if (!line.length) return;
    NSString *entry = [NSString stringWithFormat:@"%.3f %@\n", CFAbsoluteTimeGetCurrent(), line];
    NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:path];
    if (!fh) { [entry writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil]; return; }
    @try { [fh seekToEndOfFile]; [fh writeData:[entry dataUsingEncoding:NSUTF8StringEncoding]]; }
    @catch (__unused NSException *e) {}
    @try { [fh closeFile]; } @catch (__unused NSException *e) {}
}
static void VCAMAppendProcessLog(NSString *line) { VCAMAppendLog(kVCAMProcessLogPath, line); }
static void VCAMAppendMediaLog(NSString *line)   { VCAMAppendLog(kVCAMMediaLogPath,   line); }

// ─── Forward declarations ─────────────────────────────────────────────────────
@interface VCAMStreamReceiver : NSObject
- (void)startWithHost:(NSString *)host port:(int)port;
- (void)stop;
- (CMSampleBufferRef)copyLatestSampleBuffer;
- (CVImageBufferRef)copyLatestImageBuffer;
- (CGImageRef)copyLatestCGImage;  // +1 ref，调用方负责 CGImageRelease
@end

@interface VCAMService : NSObject
+ (instancetype)shared;
- (void)startObserver;
- (void)applyConfig;
- (void)syncAndCheckStatus;
- (void)ensureReceiverStartedIfNeeded;
- (CMSampleBufferRef)copyLatestSampleBuffer;
- (CVImageBufferRef)copyLatestImageBuffer;
- (CGImageRef)copyLatestCGImage;
@end

@interface VCAMManager : NSObject
+ (void)syncAndCheckStatus;
+ (CMSampleBufferRef)copyLatestSampleBuffer;
+ (CVImageBufferRef)copyLatestImageBuffer;
+ (CGImageRef)copyLatestCGImage;
@end

// ─── 共享 CIContext ───────────────────────────────────────────────────────────
static CIContext *VCAMSharedCIContext(void) {
    static CIContext *sCtx = nil;
    static dispatch_once_t tok;
    dispatch_once(&tok, ^{
        sCtx = [CIContext contextWithOptions:nil];
        VCAMAppendMediaLog(sCtx ? @"CIContext ok" : @"CIContext failed");
    });
    return sCtx;
}

// ─── JPEG → CVPixelBufferRef（修复：网络线程预处理 EXIF，hook 线程不碰 GPU）──────
//
//  旧版用 CGImageCreateWithJPEGDataProvider，完全忽略 EXIF 方向，
//  导致竖屏 JPEG 以横屏原始布局存入 buffer（旋转 90°、深度检测失败→高斯模糊）。
//
//  修复：
//    1. [CIImage imageWithData:] 自动应用 EXIF 方向（在网络接收线程执行，不影响相机线程）
//    2. [CIContext createCGImage:fromRect:] 转为标准 CGImage（CG 坐标系，与后续
//       CGContextDrawImage 完全兼容，保留原来快速 CPU 路径）
//    3. Hook 里仍用原来的 CGContextDrawImage（快速 CPU），不引入 GPU 延迟
// ─────────────────────────────────────────────────────────────────────────────
static CVPixelBufferRef VCAMCreatePixelBufferFromJPEGData(NSData *jpegData) {
    if (!jpegData.length) return NULL;

    // 步骤 1: CIImage 读取 EXIF 并自动校正朝向（网络线程执行，不影响相机线程帧率）
    CIImage *ci = [CIImage imageWithData:jpegData];
    if (!ci) return NULL;

    // 步骤 2: 转为 CGImage（CG 坐标系，EXIF 已烘入像素，尺寸已是校正后的尺寸）
    CGImageRef cgImage = [VCAMSharedCIContext() createCGImage:ci fromRect:ci.extent];
    if (!cgImage) return NULL;

    size_t w = CGImageGetWidth(cgImage);
    size_t h = CGImageGetHeight(cgImage);

    NSDictionary *attrs = @{
        (id)kCVPixelBufferPixelFormatTypeKey:              @(kCVPixelFormatType_32BGRA),
        (id)kCVPixelBufferIOSurfacePropertiesKey:          @{},
        (id)kCVPixelBufferCGImageCompatibilityKey:         @YES,
        (id)kCVPixelBufferCGBitmapContextCompatibilityKey: @YES,
    };

    CVPixelBufferRef buf = NULL;
    if (CVPixelBufferCreate(kCFAllocatorDefault, w, h, kCVPixelFormatType_32BGRA,
                            (__bridge CFDictionaryRef)attrs, &buf) != kCVReturnSuccess || !buf) {
        CGImageRelease(cgImage); return NULL;
    }

    // 步骤 3: 用 CGContextDrawImage 写入（与原始流程完全一致，保留 CG 坐标约定）
    CVPixelBufferLockBaseAddress(buf, 0);
    CGColorSpaceRef cs  = CGColorSpaceCreateDeviceRGB();
    CGContextRef    ctx = CGBitmapContextCreate(
        CVPixelBufferGetBaseAddress(buf), w, h, 8,
        CVPixelBufferGetBytesPerRow(buf), cs,
        kCGBitmapByteOrder32Little | kCGImageAlphaPremultipliedFirst);
    CGColorSpaceRelease(cs);
    if (ctx) {
        CGContextDrawImage(ctx, CGRectMake(0, 0, w, h), cgImage);
        CGContextRelease(ctx);
    }
    CVPixelBufferUnlockBaseAddress(buf, 0);
    CGImageRelease(cgImage);
    return buf;
}

// ─── 平面感知 CPU memcpy（NV12 双平面 / BGRA 单平面均适用）──────────────────────
static void VCAMMemcpyPixelBuffer(CVPixelBufferRef dst, CVPixelBufferRef src) {
    if (!dst || !src) return;
    CVPixelBufferLockBaseAddress(src, kCVPixelBufferLock_ReadOnly);
    CVPixelBufferLockBaseAddress(dst, 0);
    if (CVPixelBufferIsPlanar(src)) {
        size_t planes = CVPixelBufferGetPlaneCount(src);
        for (size_t p = 0; p < planes; p++) {
            const uint8_t *sb = (const uint8_t *)CVPixelBufferGetBaseAddressOfPlane(src, p);
            uint8_t       *db = (uint8_t *)CVPixelBufferGetBaseAddressOfPlane(dst, p);
            if (!sb || !db) continue;
            size_t srcBPR = CVPixelBufferGetBytesPerRowOfPlane(src, p);
            size_t dstBPR = CVPixelBufferGetBytesPerRowOfPlane(dst, p);
            size_t h      = CVPixelBufferGetHeightOfPlane(src, p);
            size_t rowB   = MIN(srcBPR, dstBPR);
            for (size_t row = 0; row < h; row++)
                memcpy(db + row * dstBPR, sb + row * srcBPR, rowB);
        }
    } else {
        const uint8_t *sb = (const uint8_t *)CVPixelBufferGetBaseAddress(src);
        uint8_t       *db = (uint8_t *)CVPixelBufferGetBaseAddress(dst);
        if (sb && db) {
            size_t srcBPR = CVPixelBufferGetBytesPerRow(src);
            size_t dstBPR = CVPixelBufferGetBytesPerRow(dst);
            size_t h      = CVPixelBufferGetHeight(src);
            size_t rowB   = MIN(srcBPR, dstBPR);
            for (size_t row = 0; row < h; row++)
                memcpy(db + row * dstBPR, sb + row * srcBPR, rowB);
        }
    }
    CVPixelBufferUnlockBaseAddress(dst, 0);
    CVPixelBufferUnlockBaseAddress(src, kCVPixelBufferLock_ReadOnly);
}

// ─── 原地覆写 ────────────────────────────────────────────────────────────────
//
//  关键原理：iPhone 物理传感器横向（landscape）安装。
//  当 dstW > dstH（横向缓冲区）时，系统方向元数据会在保存/编码阶段再额外旋转 +90°。
//  因此必须在画图前预先旋转 -90°，让系统 +90° 旋转后还原为正向。
//
//  路径 A (BGRA)  → CGBitmapContext 纯 CPU，~1-2ms/帧，不阻塞相机线程
//  路径 B (YUV…) → CIContext GPU 渲染，同原版
//  比例策略：Aspect-Fill 居中裁切
// ─────────────────────────────────────────────────────────────────────────────
static BOOL VCAMReplacePixelsInPlace(CGImageRef fakeImage, CVPixelBufferRef realBuf) {
    if (!fakeImage || !realBuf) return NO;

    size_t srcW   = CGImageGetWidth(fakeImage);
    size_t srcH   = CGImageGetHeight(fakeImage);
    size_t dstW   = CVPixelBufferGetWidth(realBuf);
    size_t dstH   = CVPixelBufferGetHeight(realBuf);
    OSType dstFmt = CVPixelBufferGetPixelFormatType(realBuf);

    if (!srcW || !srcH || !dstW || !dstH) return NO;

    // 横向缓冲区（物理传感器自然方向）需要预旋转补偿系统方向附件
    BOOL needsRotation = (dstW > dstH);

    static uint64_t sReplaceCount = 0;
    sReplaceCount++;
    if (sReplaceCount <= 5 || (sReplaceCount % 300) == 0)
        VCAMAppendMediaLog([NSString stringWithFormat:
            @"replace#=%llu src=%zux%zu dst=%zux%zu fmt=%u rot=%d",
            (unsigned long long)sReplaceCount, srcW, srcH, dstW, dstH,
            (unsigned)dstFmt, (int)needsRotation]);

    // ── 缓存检查：同一张图 + 相同尺寸/格式 → 直接 CPU memcpy，零 GPU ────────────
    os_unfair_lock_lock(&g_cacheLock);
    BOOL cacheHit = (gLastRenderedFakeImage == fakeImage)
                 && gCachedScaledBuffer
                 && (CVPixelBufferGetWidth(gCachedScaledBuffer)           == dstW)
                 && (CVPixelBufferGetHeight(gCachedScaledBuffer)          == dstH)
                 && (CVPixelBufferGetPixelFormatType(gCachedScaledBuffer) == dstFmt);
    CVPixelBufferRef cachedBuf = cacheHit
        ? (CVPixelBufferRef)CFRetain(gCachedScaledBuffer) : NULL;
    os_unfair_lock_unlock(&g_cacheLock);

    if (cachedBuf) {
        VCAMMemcpyPixelBuffer(realBuf, cachedBuf);
        CFRelease(cachedBuf);
        if (sReplaceCount <= 5) VCAMAppendMediaLog(@"replace cache-hit memcpy ok");
        return YES;
    }

    // ── 缓存未命中：创建与 realBuf 同格式/尺寸的私有 buffer ─────────────────────
    NSDictionary *cacheAttrs = @{
        (id)kCVPixelBufferPixelFormatTypeKey:     @(dstFmt),
        (id)kCVPixelBufferIOSurfacePropertiesKey: @{},
    };
    CVPixelBufferRef newCache = NULL;
    CVReturn cvRet = CVPixelBufferCreate(kCFAllocatorDefault, dstW, dstH, dstFmt,
                                         (__bridge CFDictionaryRef)cacheAttrs, &newCache);
    // 渲染目标：优先写入 newCache；若创建失败则 fallback 直接写 realBuf（原始行为）
    CVPixelBufferRef renderTarget = (cvRet == kCVReturnSuccess && newCache) ? newCache : realBuf;

    BOOL rendered = NO;

    if (dstFmt == kCVPixelFormatType_32BGRA || dstFmt == kCVPixelFormatType_32ARGB) {
        // ── 路径 A：CGBitmapContext 纯 CPU 渲染 ──────────────────────────────
        CVPixelBufferLockBaseAddress(renderTarget, 0);
        CGColorSpaceRef cs  = CGColorSpaceCreateDeviceRGB();
        CGContextRef    ctx = CGBitmapContextCreate(
            CVPixelBufferGetBaseAddress(renderTarget), dstW, dstH, 8,
            CVPixelBufferGetBytesPerRow(renderTarget), cs,
            kCGBitmapByteOrder32Little | kCGImageAlphaPremultipliedFirst);
        CGColorSpaceRelease(cs);
        if (ctx) {
            CGContextSetBlendMode(ctx, kCGBlendModeCopy);
            CGContextClipToRect(ctx, CGRectMake(0, 0, (CGFloat)dstW, (CGFloat)dstH));
            if (needsRotation) {
                // 1. 平移原点至画布中心
                CGContextTranslateCTM(ctx, (CGFloat)dstW / 2.0, (CGFloat)dstH / 2.0);
                // 2. 旋转 +90°（CG 底部原点→内存顶部原点隐式翻转后为 CW，正好抵消系统 EXIF CCW）
                CGContextRotateCTM(ctx, M_PI_2);
                // 3. 旋转后有效画布为 dstH 宽 × dstW 高（竖向坐标系），按此做 Aspect-Fill
                CGFloat fill = MAX((CGFloat)dstH / (CGFloat)srcW,
                                   (CGFloat)dstW / (CGFloat)srcH);
                CGFloat fw = (CGFloat)srcW * fill;
                CGFloat fh = (CGFloat)srcH * fill;
                CGContextDrawImage(ctx, CGRectMake(-fw * 0.5, -fh * 0.5, fw, fh), fakeImage);
            } else {
                CGFloat fill = MAX((CGFloat)dstW / (CGFloat)srcW,
                                   (CGFloat)dstH / (CGFloat)srcH);
                CGFloat fw = (CGFloat)srcW * fill;
                CGFloat fh = (CGFloat)srcH * fill;
                CGContextDrawImage(ctx,
                    CGRectMake(-(fw - (CGFloat)dstW) * 0.5,
                               -(fh - (CGFloat)dstH) * 0.5, fw, fh),
                    fakeImage);
            }
            CGContextRelease(ctx);
            rendered = YES;
        }
        CVPixelBufferUnlockBaseAddress(renderTarget, 0);
        if (rendered && sReplaceCount <= 5) VCAMAppendMediaLog(@"replace A (BGRA) cache-miss ok");
    } else {
        // ── 路径 B：CIContext GPU 渲染（缓存未命中时每新帧只执行一次）──────────
        @autoreleasepool {
            CIImage *ci = [CIImage imageWithCGImage:fakeImage];
            if (!ci) {
                if (sReplaceCount <= 5) VCAMAppendMediaLog(@"CIImage nil");
            } else {
                CIContext *ctx = VCAMSharedCIContext();
                if (!ctx) {
                    if (sReplaceCount <= 5) VCAMAppendMediaLog(@"CIContext nil");
                } else {
                    if (needsRotation) {
                        // 旋转 +90° 补偿横向传感器方向附件（与路径 A 方向一致）
                        ci = [ci imageByApplyingTransform:CGAffineTransformMakeRotation(M_PI_2)];
                        // 归一化原点到 (0, 0)
                        CGRect ext = ci.extent;
                        if (ext.origin.x != 0 || ext.origin.y != 0)
                            ci = [ci imageByApplyingTransform:
                                    CGAffineTransformMakeTranslation(-ext.origin.x, -ext.origin.y)];
                    }
                    CGRect ext = ci.extent;
                    if (ext.size.width > 0 && ext.size.height > 0) {
                        // 等比放大 + 居中裁切到目标尺寸
                        CGFloat fill    = MAX((CGFloat)dstW / ext.size.width,
                                              (CGFloat)dstH / ext.size.height);
                        CIImage *scaled = [ci imageByApplyingTransform:
                                            CGAffineTransformMakeScale(fill, fill)];
                        CGRect   se     = scaled.extent;
                        CGRect   crop   = CGRectMake(
                            se.origin.x + (se.size.width  - (CGFloat)dstW) * 0.5,
                            se.origin.y + (se.size.height - (CGFloat)dstH) * 0.5,
                            (CGFloat)dstW, (CGFloat)dstH);
                        CIImage *positioned = [[scaled imageByCroppingToRect:crop]
                            imageByApplyingTransform:
                                CGAffineTransformMakeTranslation(-crop.origin.x, -crop.origin.y)];
                        [ctx render:positioned toCVPixelBuffer:renderTarget];
                        rendered = YES;
                    }
                }
            }
        }
        if (rendered && sReplaceCount <= 5) VCAMAppendMediaLog(@"replace B (CIContext) cache-miss ok");
    }

    if (rendered && newCache) {
        // 更新缓存（新帧渲染完毕后缓存结果）
        os_unfair_lock_lock(&g_cacheLock);
        if (gCachedScaledBuffer) { CFRelease(gCachedScaledBuffer); gCachedScaledBuffer = NULL; }
        gCachedScaledBuffer    = (CVPixelBufferRef)CFRetain(newCache);
        gLastRenderedFakeImage = fakeImage;  // 裸指针，不 retain，仅作 key 比较
        os_unfair_lock_unlock(&g_cacheLock);
        // 将 newCache 内容 memcpy 到真正的系统 realBuf
        VCAMMemcpyPixelBuffer(realBuf, newCache);
    }
    // renderTarget == realBuf（fallback）时数据已直接写入，无需 memcpy

    if (newCache) CFRelease(newCache);
    return rendered;
}

// ─── The actual hook function ─────────────────────────────────────────────────
//
//  PTS 时间戳锁：录像模式下 VideoToolbox 编码器、音频时钟、预览层会并发地
//  对同一帧反复调用 CMSampleBufferGetImageBuffer（每帧可达 10+ 次）。
//  若每次都触发 VCAMReplacePixelsInPlace（尤其 CIContext GPU 路径），
//  会与硬件编码器争抢 GPU，导致 mediaserverd GPU 死锁、录像模糊卡死。
//
//  修复：记录上一帧 PTS，同一帧只执行一次覆写，后续并发调用直接放行。
// ─────────────────────────────────────────────────────────────────────────────
static CVImageBufferRef VCAMHookedCMSampleBufferGetImageBuffer(CMSampleBufferRef sampleBuffer) {
    if (!gOrigCMSampleBufferGetImageBuffer) return NULL;
    [VCAMManager syncAndCheckStatus];

    CVImageBufferRef originalImage = gOrigCMSampleBufferGetImageBuffer(sampleBuffer);

    if (originalImage) {
        // 提取本帧唯一 PTS，防止同一帧被多线程并发覆写
        CMTime pts = CMSampleBufferGetPresentationTimeStamp(sampleBuffer);
        BOOL isNewFrame = NO;

        os_unfair_lock_lock(&g_ptsLock);
        if (pts.value != gLastReplacedPTS.value || pts.timescale != gLastReplacedPTS.timescale) {
            gLastReplacedPTS = pts;
            isNewFrame = YES;
        }
        os_unfair_lock_unlock(&g_ptsLock);

        // 只有全新帧才执行覆写（每秒严格最多 30 次），解除 GPU 死锁
        if (isNewFrame) {
            gVCAMHookProbeCount++;
            if (gVCAMHookProbeCount <= 5 || (gVCAMHookProbeCount % 300) == 0)
                VCAMAppendMediaLog([NSString stringWithFormat:
                    @"hook frame rendered=%llu",
                    (unsigned long long)gVCAMHookProbeCount]);

            CGImageRef fakeImage = [VCAMManager copyLatestCGImage]; // +1
            if (fakeImage) {
                VCAMReplacePixelsInPlace(fakeImage, (CVPixelBufferRef)originalImage);
                CGImageRelease(fakeImage);
            }
        }
    }

    return originalImage;
}

// ─── VCAMStreamReceiver (MJPEG) ───────────────────────────────────────────────
@interface VCAMStreamReceiver ()
- (void)connectLoop:(NSNumber *)generationObj;
- (void)resetStreamStateLocked;
- (void)storeImageBuffer:(CVImageBufferRef)imageBuffer;
@end

@implementation VCAMStreamReceiver {
    NSString      *_host;
    int            _port;
    BOOL           _running;
    int            _socketFD;
    NSThread      *_loopThread;
    NSInteger      _generation;

    CMSampleBufferRef  _latestSample;
    CVImageBufferRef   _latestImageBuffer;
    CGImageRef         _latestCGImage;   // EXIF 校正后的 CGImage，供原地覆写使用
    uint64_t           _frameCount;
    int                _connectFailCount;
}

- (instancetype)init {
    self = [super init];
    if (self) _socketFD = -1;
    return self;
}

- (void)dealloc {
    [self stop];
    @synchronized (self) { [self resetStreamStateLocked]; }
}

- (void)closeSocketLocked {
    if (_socketFD >= 0) {
        shutdown(_socketFD, SHUT_RDWR);
        close(_socketFD);
        _socketFD = -1;
    }
}

- (void)resetStreamStateLocked {
    if (_latestSample)      { CFRelease(_latestSample);      _latestSample      = NULL; }
    if (_latestImageBuffer) { CFRelease(_latestImageBuffer); _latestImageBuffer = NULL; }
    if (_latestCGImage)     { CGImageRelease(_latestCGImage); _latestCGImage    = NULL; }
}

- (void)startWithHost:(NSString *)host port:(int)port {
    if (!host.length || port <= 0 || port > 65535) {
        VCAMAppendMediaLog([NSString stringWithFormat:@"startWithHost ignored host=%@ port=%d", host ?: @"(nil)", port]);
        return;
    }
    @synchronized (self) {
        if (_running && [_host isEqualToString:host] && _port == port) return;
        [self closeSocketLocked];
        _running = NO;
        _generation++;
        _host    = [host copy];
        _port    = port;
        _running = YES;
        _connectFailCount = 0;
        [self resetStreamStateLocked];

        NSInteger gen = _generation;
        _loopThread = [[NSThread alloc] initWithTarget:self selector:@selector(connectLoop:) object:@(gen)];
        _loopThread.name = @"VCAMClone.ConnectLoop";
        [_loopThread start];
    }
    VCAMAppendMediaLog([NSString stringWithFormat:@"receiver start host=%@ port=%d", host, port]);
}

- (void)stop {
    @synchronized (self) {
        _running = NO;
        _generation++;
        [self closeSocketLocked];
        [self resetStreamStateLocked];
    }
    VCAMAppendMediaLog(@"receiver stop");
}

- (void)connectLoop:(NSNumber *)generationObj {
    NSInteger generation = generationObj.integerValue;
    @autoreleasepool {
        while (YES) {
            @autoreleasepool {
                NSString *host = nil; int port = 0;
                @synchronized (self) {
                    if (!_running || generation != _generation) break;
                    host = _host; port = _port;
                }

                int fd = VCAMConnectWithTimeout(host.UTF8String, port, 2);
                if (fd < 0) {
                    _connectFailCount++;
                    if (_connectFailCount <= 5 || (_connectFailCount % 15) == 0)
                        VCAMAppendMediaLog([NSString stringWithFormat:
                            @"connect failed host=%@ port=%d errno=%d", host ?: @"(nil)", port, errno]);
                    [NSThread sleepForTimeInterval:2.0];
                    continue;
                }

                _connectFailCount = 0;
                VCAMAppendMediaLog([NSString stringWithFormat:@"connected host=%@ port=%d", host, port]);

                @synchronized (self) {
                    if (!_running || generation != _generation) { close(fd); break; }
                    _socketFD = fd;
                }

                BOOL shouldContinue = YES;
                while (shouldContinue) {
                    @autoreleasepool {
                        @synchronized (self) {
                            if (!_running || generation != _generation) {
                                shouldContinue = NO; return;
                            }
                        }

                        uint32_t lenBE = 0;
                        if (!VCAMReadExact(fd, &lenBE, 4)) {
                            VCAMAppendMediaLog(@"read len failed/disconnected");
                            shouldContinue = NO; return;
                        }
                        uint32_t len = ntohl(lenBE);
                        if (len == 0 || len > 10 * 1024 * 1024) {
                            VCAMAppendMediaLog([NSString stringWithFormat:@"invalid len=%u", len]);
                            shouldContinue = NO; return;
                        }

                        NSMutableData *payload = [NSMutableData dataWithLength:len];
                        if (!VCAMReadExact(fd, payload.mutableBytes, len)) {
                            VCAMAppendMediaLog([NSString stringWithFormat:@"read payload failed len=%u", len]);
                            shouldContinue = NO; return;
                        }

                        // VCAMCreatePixelBufferFromJPEGData 内部已用 CIImage 校正 EXIF，
                        // CIContext 操作在此（网络线程）完成，不占用相机回调线程的时间
                        CVPixelBufferRef pix = VCAMCreatePixelBufferFromJPEGData(payload);
                        if (pix) {
                            [self storeImageBuffer:(CVImageBufferRef)pix];
                            CVPixelBufferRelease(pix);
                        }
                    }
                }

                @synchronized (self) { [self closeSocketLocked]; }
                @synchronized (self) { if (!_running || generation != _generation) break; }
                [NSThread sleepForTimeInterval:2.0];
            }
        }
    }
}

- (void)storeImageBuffer:(CVImageBufferRef)imageBuffer {
    // 从 BGRA pixel buffer 提取 CGImage，供原地覆写路径使用
    // （pixel buffer 已由 VCAMCreatePixelBufferFromJPEGData 进行 EXIF 校正）
    CGImageRef cgImg = NULL;
    CVPixelBufferLockBaseAddress((CVPixelBufferRef)imageBuffer, kCVPixelBufferLock_ReadOnly);
    size_t w = CVPixelBufferGetWidth((CVPixelBufferRef)imageBuffer);
    size_t h = CVPixelBufferGetHeight((CVPixelBufferRef)imageBuffer);
    CGColorSpaceRef cs  = CGColorSpaceCreateDeviceRGB();
    CGContextRef    ctx = CGBitmapContextCreate(
        CVPixelBufferGetBaseAddress((CVPixelBufferRef)imageBuffer), w, h, 8,
        CVPixelBufferGetBytesPerRow((CVPixelBufferRef)imageBuffer), cs,
        kCGBitmapByteOrder32Little | kCGImageAlphaPremultipliedFirst);
    CGColorSpaceRelease(cs);
    if (ctx) { cgImg = CGBitmapContextCreateImage(ctx); CGContextRelease(ctx); }
    CVPixelBufferUnlockBaseAddress((CVPixelBufferRef)imageBuffer, kCVPixelBufferLock_ReadOnly);

    CMVideoFormatDescriptionRef fmt = NULL;
    if (CMVideoFormatDescriptionCreateForImageBuffer(kCFAllocatorDefault, imageBuffer, &fmt) != noErr || !fmt) {
        if (cgImg) CGImageRelease(cgImg);
        return;
    }

    CMTime pts = CMClockGetTime(CMClockGetHostTimeClock());
    CMSampleTimingInfo timing = {
        .duration               = CMTimeMake(1, 30),
        .presentationTimeStamp  = pts,
        .decodeTimeStamp        = kCMTimeInvalid
    };

    CMSampleBufferRef sample = NULL;
    OSStatus st = CMSampleBufferCreateReadyWithImageBuffer(
        kCFAllocatorDefault, imageBuffer, fmt, &timing, &sample);
    CFRelease(fmt);
    if (st != noErr || !sample) {
        if (cgImg) CGImageRelease(cgImg);
        return;
    }

    VCAMSetSampleAttachments(sample);

    @synchronized (self) {
        if (_latestImageBuffer) { CFRelease(_latestImageBuffer); _latestImageBuffer = NULL; }
        _latestImageBuffer = (CVImageBufferRef)CFRetain(imageBuffer);
        if (_latestSample)      { CFRelease(_latestSample);      _latestSample      = NULL; }
        _latestSample = sample;
        if (_latestCGImage)     { CGImageRelease(_latestCGImage); _latestCGImage    = NULL; }
        _latestCGImage = cgImg;   // 转让所有权
        _frameCount++;
        if (_frameCount <= 3 || (_frameCount % 120) == 0) {
            VCAMAppendMediaLog([NSString stringWithFormat:
                @"frame#=%llu size=%zux%zu", (unsigned long long)_frameCount, w, h]);
        }
    }
}

- (CMSampleBufferRef)copyLatestSampleBuffer {
    @synchronized (self) {
        if (_latestSample) { CFRetain(_latestSample); return _latestSample; }
        return NULL;
    }
}

- (CVImageBufferRef)copyLatestImageBuffer {
    @synchronized (self) {
        if (_latestImageBuffer) { CFRetain(_latestImageBuffer); return _latestImageBuffer; }
        return NULL;
    }
}

- (CGImageRef)copyLatestCGImage {
    @synchronized (self) {
        if (_latestCGImage) { CGImageRetain(_latestCGImage); return _latestCGImage; }
        return NULL;
    }
}

@end

// ─── VCAMService ──────────────────────────────────────────────────────────────
@implementation VCAMService {
    VCAMStreamReceiver *_receiver;
    BOOL        _enabled;
    NSString   *_host;
    int         _port;
    BOOL        _receiverStarted;
    int         _notifyToken;
}

+ (instancetype)shared {
    static VCAMService *inst = nil;
    static dispatch_once_t tok;
    dispatch_once(&tok, ^{ inst = [[VCAMService alloc] init]; });
    return inst;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _receiver = [[VCAMStreamReceiver alloc] init];
        _host     = @"127.0.0.1";
        _port     = 7878;
    }
    return self;
}

- (NSDictionary *)defaultConfig { return @{@"enabled":@NO, @"host":@"127.0.0.1", @"port":@7878}; }

- (NSDictionary *)loadConfig {
    NSData *data = [NSData dataWithContentsOfFile:kVCAMConfigPath];
    if (data) {
        id obj = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        if ([obj isKindOfClass:[NSDictionary class]]) return obj;
    }
    NSDictionary *plist = [NSDictionary dictionaryWithContentsOfFile:kVCAMConfigPath];
    return [plist isKindOfClass:[NSDictionary class]] ? plist : [self defaultConfig];
}

- (void)applyConfig {
    gVCAMLastManagerSyncAt = 0;
    [self syncAndCheckStatus];
}

- (void)syncAndCheckStatus {
    CFTimeInterval now = CFAbsoluteTimeGetCurrent();
    if ((now - gVCAMLastManagerSyncAt) < 0.40) return;
    gVCAMLastManagerSyncAt = now;

    NSDictionary *cfg = [self loadConfig];
    id        enabledObj = [cfg[@"enabled"] respondsToSelector:@selector(boolValue)] ? cfg[@"enabled"] : @NO;
    BOOL      enabled = [enabledObj boolValue];
    NSString *host    = [cfg[@"host"] isKindOfClass:[NSString class]] ? cfg[@"host"] : @"127.0.0.1";
    host = [[host stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]
               stringByReplacingOccurrencesOfString:@"\u3002" withString:@"."];
    if (!host.length || [host isEqualToString:@"localhost"]) host = @"127.0.0.1";
    int port = [[cfg[@"port"] respondsToSelector:@selector(intValue)] ? cfg[@"port"] : @7878 intValue];
    if (port <= 0 || port > 65535) port = 7878;

    BOOL changed = NO;
    @synchronized (self) {
        changed = (_enabled != enabled) || (_port != port) || ![_host isEqualToString:host];
        _enabled = enabled; _host = [host copy]; _port = port;
        if (!_enabled) { [_receiver stop]; _receiverStarted = NO; }
        else           { [_receiver startWithHost:_host port:_port]; _receiverStarted = YES; }
    }

    if (changed || (gVCAMHookProbeCount % 180) == 0)
        VCAMAppendMediaLog([NSString stringWithFormat:
            @"sync enabled=%d host=%@ port=%d", enabled?1:0, host, port]);
}

- (void)startObserver {
    if (_notifyToken) return;
    __weak VCAMService *weak = self;
    notify_register_dispatch(kVCAMConfigNotify, &_notifyToken, dispatch_get_main_queue(), ^(int __unused t) {
        [weak applyConfig];
    });
}

- (void)ensureReceiverStartedIfNeeded { [self syncAndCheckStatus]; }

- (CMSampleBufferRef)copyLatestSampleBuffer {
    [self ensureReceiverStartedIfNeeded]; return [_receiver copyLatestSampleBuffer];
}
- (CVImageBufferRef)copyLatestImageBuffer {
    [self ensureReceiverStartedIfNeeded]; return [_receiver copyLatestImageBuffer];
}
- (CGImageRef)copyLatestCGImage {
    [self ensureReceiverStartedIfNeeded]; return [_receiver copyLatestCGImage];
}

@end

// ─── VCAMManager ──────────────────────────────────────────────────────────────
@implementation VCAMManager
+ (void)syncAndCheckStatus     { [[VCAMService shared] syncAndCheckStatus]; }
+ (CMSampleBufferRef)copyLatestSampleBuffer { return [[VCAMService shared] copyLatestSampleBuffer]; }
+ (CVImageBufferRef)copyLatestImageBuffer   { return [[VCAMService shared] copyLatestImageBuffer]; }
+ (CGImageRef)copyLatestCGImage             { return [[VCAMService shared] copyLatestCGImage]; }
@end

// ─── Constructor ──────────────────────────────────────────────────────────────
%ctor {
    @autoreleasepool {
        NSString *proc = NSProcessInfo.processInfo.processName ?: @"unknown";
        VCAMAppendProcessLog([NSString stringWithFormat:@"load process=%@", proc]);
        if (!gOrigCMSampleBufferGetImageBuffer) {
            MSHookFunction((void *)CMSampleBufferGetImageBuffer,
                           (void *)VCAMHookedCMSampleBufferGetImageBuffer,
                           (void **)&gOrigCMSampleBufferGetImageBuffer);
            VCAMAppendProcessLog([NSString stringWithFormat:@"hook CMSampleBufferGetImageBuffer process=%@", proc]);
        }
        [[VCAMService shared] startObserver];
        [[VCAMService shared] applyConfig];
        NSLog(@"[VCAMClone] loaded in process=%@", proc);
        notify_post(kVCAMMediaNotify);
    }
}
